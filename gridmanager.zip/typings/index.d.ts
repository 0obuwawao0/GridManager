declare module '*.html';
