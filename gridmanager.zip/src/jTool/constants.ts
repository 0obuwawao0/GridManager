// 生成的Sizzle中DOM所存储的字段
export const DOM_LIST = 'DOMList';

// 生成的Sizzle中标识对像为jTool的字段
export const JTOOL_KEY = 'jTool';

// 生成jtool对像期间临时使用的DOM id
export const JTOOL_DOM_ID = 'jTool-create-dom';
