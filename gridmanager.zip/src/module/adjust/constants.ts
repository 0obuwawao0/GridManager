// 事件源class name
export const CLASS_ADJUST_ACTION = 'gm-adjust-action';

// 正在移动中 class name
export const CLASS_ADJUST_ING = 'gm-adjust-ing';
