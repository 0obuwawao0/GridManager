// 禁用点击 class name
export const CLASS_NO_CLICK = 'no-click';

// 配置中 class name
export const CLASS_CONFIG_ING = 'gm-config-ing';

// 配置区域 class name
export const CLASS_CONFIG = 'gm-config-area';
