// 拖拽事件源 class name
export const CLASS_DRAG_ACTION = 'gm-drag-action';

// 拖拽中 class name
export const CLASS_DRAG_ING = 'gm-drag-ongoing';

// 镜像 class name
export const CLASS_DREAMLAND = 'gm-dreamland-div';
