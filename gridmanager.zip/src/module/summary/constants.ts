// 汇总行在div上的标志
export const SUMMARY_FLAG = 'gm-summary';

// 汇总行所在tr上的标志
export const SUMMARY_ROW = `${SUMMARY_FLAG}-row`;
