// filter 区域 class name
export const CLASS_FILTER = 'gm-filter-area';

// 存在选中项时的ICON class name
export const CLASS_FILTER_SELECTED = 'filter-selected';

// filter 容器 class name
export const CLASS_FILTER_CONTENT = 'fa-con';
