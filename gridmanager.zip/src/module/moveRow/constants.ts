// 拖拽中 class name
export const CLASS_DRAG_ING = 'gm-move-row-ongoing';

// 镜像 class name
export const CLASS_DREAMLAND = 'dreamland-row-div';

// td禁止移动标识
export const DISABLE_MOVE = 'disable-move';
