// 列合并属性
export const ROW_SPAN = 'rowspan';

// 当前列被合并标识
export const MERGE_TD = 'merge-td';

// 列合并最后一个
export const ROW_LAST = 'last-rowspan';
