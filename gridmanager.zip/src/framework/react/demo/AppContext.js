import React from 'react';
const AppContext = React.createContext({gridManagerName: 'testReact'});

export default AppContext;
