import fixed from '../../src/module/fixed';

describe('fixed', () => {
    describe('destroy', () => {
        let settings = null;
        beforeEach(() => {
        });
        afterEach(() => {
            settings = null;
        });
        it('基础验证', () => {
        });
    });
});
