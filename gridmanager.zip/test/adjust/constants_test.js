import { CLASS_ADJUST_ACTION, CLASS_ADJUST_ING } from '../../src/module/adjust/constants';
describe('constants', () => {
    it('CLASS_ADJUST_ACTION', () => {
        expect(CLASS_ADJUST_ACTION).toBe('gm-adjust-action');
    });
    it('CLASS_ADJUST_ING', () => {
        expect(CLASS_ADJUST_ING).toBe('gm-adjust-ing');
    });
});
